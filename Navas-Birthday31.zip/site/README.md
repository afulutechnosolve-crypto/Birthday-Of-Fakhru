# Chapter 31 — Fakhrudheen Navas MP

A cinematic, interactive 31st birthday experience. Pure HTML/CSS/JS —
no build step, no dependencies to install. Works on GitHub Pages as-is.

## What it is

A scroll-driven "movie" that opens as a mysterious AI app-builder,
then reveals a birthday chapter, a living family constellation, and a
cinematic 31-photo memory journey — ending on Happy Birthday.

## Run it locally

Just open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

(Opening `index.html` directly via `file://` also works, but a local
server avoids any browser image-loading quirks.)

## Put it on GitHub Pages

1. Create a new **public** repo named `Navas-Birthday31` on GitHub.
2. From inside this folder:

   ```bash
   git init
   git add .
   git commit -m "Chapter 31"
   git branch -M main
   git remote add origin https://github.com/<your-username>/Navas-Birthday31.git
   git push -u origin main
   ```
3. On GitHub: **Settings → Pages → Source → Deploy from branch → main → / (root)**.
4. Your link will be `https://<your-username>.github.io/Navas-Birthday31/`
   (takes a minute or two to go live after the first push).

## Structure

```
index.html      the whole scene sequence (markup only)
styles.css      all visual design + animation keyframes
script.js       scene engine, audio, family constellation, photo journey
images/         31 memory photos, each as .webp (primary) + .jpg (fallback)
```

## Editing content

- **Family names/roles**: top of `script.js`, the `FAMILY` object.
- **Photo order**: images are named `1.webp`…`31.webp` in `images/` —
  rename/reorder files to change sequence.
- **Colors/fonts**: CSS custom properties at the top of `styles.css`.

Nothing beyond what was explicitly provided (names, relationships,
photos) was invented anywhere in this build.
